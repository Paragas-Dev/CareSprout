<?php
   return [
       'credentials_file' => env('FIREBASE_CREDENTIALS_FILE', storage_path('app/firebase/firebase-credentials.json')),
   ];
