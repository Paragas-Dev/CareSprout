<!-- Link to Principal Sidebar CSS -->
    <div class="sidebar">
        <div class="logo">
            <img src="<?php echo e(asset('images/name.png')); ?>" alt="CareSprout brand logo" />
        </div>

        <div class="menu-items">
            <a class="menu-item <?php echo e(request()->routeIs('principal.dashboard') ? 'active' : ''); ?>"
                href="<?php echo e(route('principal.dashboard')); ?>">
                <i class="fas fa-house"></i> Dashboard
            </a>
            <a class="menu-item <?php echo e(request()->routeIs('students') ? 'active' : ''); ?>" href="<?php echo e(route('students')); ?>">
                <i class="fas fa-user-graduate"></i> Students
            </a>
            <a class="menu-item <?php echo e(request()->routeIs('administrator') ? 'active' : ''); ?>"
                href="<?php echo e(route('administrator')); ?>">
                <i class="fas fa-user-shield"></i> Administrator
            </a>
            <a class="menu-item <?php echo e(request()->routeIs('approval') ? 'active' : ''); ?>" href="<?php echo e(route('approval')); ?>">
                <i class="fas fa-comments"></i> Messages
            </a>
            <a class="menu-item <?php echo e(request()->routeIs('announcements') ? 'active' : ''); ?>"
                href="<?php echo e(route('announcements')); ?>">
                <i class="fas fa-bullhorn"></i> Announcements
            </a>
        </div>

        <div class="bottom-menu-items">
            <a class="menu-item <?php echo e(request()->routeIs('settings') ? 'active' : ''); ?>" href="<?php echo e(route('settings')); ?>">
                <i class="fas fa-gear"></i> Settings
            </a>
            <a class="menu-item" href="#" id="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (window.auth && window.auth.signOut) {
                        window.auth.signOut().then(async function() {
                            await fetch('/logout-session', {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                                }
                            });
                            window.location.href = '/login';
                        }).catch(function(error) {
                            alert('Logout failed;' + error.message);
                        });
                    } else {
                        alert('Firebase not initialized.')
                    }
                })
            }
        })
    </script>
<?php /**PATH C:\Users\CHRISTIAN\Downloads\Capstone\care_sprout_laravel\resources\views/partials/principal-sidebar.blade.php ENDPATH**/ ?>