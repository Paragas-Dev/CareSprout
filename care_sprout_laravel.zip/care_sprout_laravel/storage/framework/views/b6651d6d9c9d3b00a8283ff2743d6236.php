<div class="sidebar">
    <div class="logo">
        <img src="<?php echo e(asset('images/name.png')); ?>" alt="CareSprout brand logo" />
    </div>

    <div class="menu-items">
        <a class="menu-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('messages') ? 'active' : ''); ?>" href="<?php echo e(route('messages')); ?>">
            <i class="fas fa-envelope"></i> Messages
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('lessons.home') ? 'active' : ''); ?>"
            href="<?php echo e(route('lessons.home')); ?>">
            <i class="fas fa-book"></i> Lessons
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('studentList') ? 'active' : ''); ?>" href="<?php echo e(route('studentList')); ?>">
            <i class="fas fa-chart-bar"></i> Student List
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('reports') ? 'active' : ''); ?>" href="<?php echo e(route('reports')); ?>">
            <i class="fas fa-chart-bar"></i> Reports
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('approval') ? 'active' : ''); ?>" href="<?php echo e(route('approval')); ?>">
            <i class="fas fa-check-circle"></i> Approval
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('leader') ? 'active' : ''); ?>" href="<?php echo e(route('leader')); ?>">
            <i class="fas fa-trophy"></i> Leaderboard
        </a>
        <a class="menu-item <?php echo e(request()->routeIs('announcement') ? 'active' : ''); ?>"
            href="<?php echo e(route('announcement')); ?>">
            <i class="fas fa-bullhorn"></i> Announcements
        </a>
    </div>

    <div class="bottom-menu-items">
        <a class="menu-item <?php echo e(request()->routeIs('settings') ? 'active' : ''); ?>" href="<?php echo e(route('settings')); ?>"><i
                class="fas fa-cog"></i> Settings</a>
        <a class="menu-item <?php echo e(request()->routeIs('lessons.archived') ? 'active' : ''); ?>"
            href="<?php echo e(route('lessons.archived')); ?>"><i class="fas fa-archive"></i> Archived Lessons</a>
        <a class="menu-item" href="#" id="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (window.auth && window.auth.signOut) {
                    window.auth.signOut().then(async function() {
                        await fetch('/logout-session', {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            }
                        });
                        window.location.href = '/login';
                    }).catch(function(error) {
                        alert('Logout failed;' + error.message);
                    });
                } else {
                    alert('Firebase not initialized.')
                }
            })
        }
    })
</script>
<script src="/js/sidebar-lessons.js"></script>
<?php /**PATH C:\Users\CHRISTIAN\Downloads\Capstone\care_sprout_laravel\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>